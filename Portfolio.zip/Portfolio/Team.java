package Portfolio;

public class Team implements Comparable<Team>{
    String name;
    Integer wins;
    Integer draws;
    Integer losses;
    Integer points;

    /**
     * This constructor initialises the fields of the class*/
    public Team(String name, int wins, int draws, int losses) {
        this.name = name;
        this.wins = wins;
        this.draws = draws;
        this.losses = losses;
        this.points = wins*3 + draws;
    }
    @Override

    public String toString(){
        return "Team: " + this.name
        + "\nWins: " + this.wins
        + "\nDraws; " + this.draws
        + "\nLosses: " + this.losses
        + "\nPoints: " + this.points;
    }
    @Override

    public int compareTo(Team t){
        return this.points.compareTo(t.points);
    }

}