package Portfolio;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class FootballLeague {
    public List<Team> teams = new LinkedList();

    public FootballLeague(){
        teams.add(new Team("Tottenham", 2, 0, 3));
        teams.add(new Team("Arsenal", 4, 1, 0));
        Collections.sort(teams);
    }

    public void remove(Team t){
        for(int i = 0; i < teams.size(); i++){
            if(teams.get(i).equals(t)){
                teams.remove(i);
                break;
            }
        }
    }

    public void wins(Team t){
        Integer wins = t.wins
                


    }

}
